﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CardAndGirls.CardBag;
using static CardAndGirls.CardBag.Card;

namespace CardAndGirls
{
    
    public partial class InfoForm : Form
    {    
        public Player Player { get; set; }

        public Card SelectCard = new Card();
        public Mon_Card fromHandCardMc;
        public Mon_Card infofromMainMc;
        public Mon_Card selcetFromMonPlace_Mc;
        public Card fromGaveCard;
        public CardType CardType;

        public InfoForm()
        {
            fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selcetFromMonPlace_Mc= new Mon_null();
            fromGaveCard= new Mon_null();
            InitializeComponent();
            
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click_1(object sender, EventArgs e)
        {

        }
/// <summary>
/// 卡牌信息框
/// </summary>
/// <param name="sender"></param>
/// <param name="e"></param>
        private void InfoForm_Load(object sender, EventArgs e)
        {
            button1.Hide();
            //位置跟随决斗盘
            if(this.Player == Player.MainPlaceInfo.Player1)
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.X -= this.Width;
                this.Location = point;
                
            }
            else
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.X += this.Player.MainPlaceInfo.MainFightPlace.Width;
                this.Location = point;

            }
            this.Text = Player.Name;
            button1.Hide();
            button2.Hide();
            button3.Hide();
        }

        public void GetInfoFromCardFromHandCard(Card card)
        {
            button1.Hide();
            button2.Hide();
            button3.Hide();
            fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selcetFromMonPlace_Mc = new Mon_null();
            fromGaveCard = new Mon_null();
            if (card is Mon_Card)
            {
                fromHandCardMc=(Mon_Card)card;
                this.NameLabel1.Text = fromHandCardMc.GiveCardState()+ fromHandCardMc.Name;
                this.LevelLabel.Text = Levelstar(fromHandCardMc.Level);
                this.DescriptionTextBox.Text = fromHandCardMc.Description;
                this.AttLabel.Text = "ATT: " + fromHandCardMc.Att.ToString();
                this.DefLabel.Text = "DEF: " + fromHandCardMc.Def.ToString();
                this.MonPicBox.Image = fromHandCardMc.cardImage;
                CardType = CardType.Mon_Card;
                button1.Text = "召唤" + fromHandCardMc.Name;

                //何时显示 “召唤”
                if (((this.Player.MainPlaceInfo.process==MainPlaceInfo.Process.Main_1)| (this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Main_2 ))&& this.Player.Active)
                {
                    if (this.Player.OriginalCallRest > 0)
                    {
                        button1.Show();
                    }
                    
                }

                
            }

        }//从手牌获得信息
        public void GetInfoFromCardFromMainPlace(Card card)
        {
            button1.Hide();
            button2.Hide();
            button3.Hide();
            fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selcetFromMonPlace_Mc = new Mon_null();
            fromGaveCard = new Mon_null();
            if (card is Mon_Card)
            {
                infofromMainMc = (Mon_Card)card;
                this.NameLabel1.Text = infofromMainMc.Name+infofromMainMc.GiveCardState();
                infofromMainMc = new Mon_null();
                selcetFromMonPlace_Mc = new Mon_null();
                fromGaveCard = new Mon_null(); ;
                this.LevelLabel.Text = Levelstar(infofromMainMc.Level);
                this.DescriptionTextBox.Text = infofromMainMc.Description;
                this.AttLabel.Text = "ATT: " + infofromMainMc.Att.ToString();
                this.DefLabel.Text = "DEF: " + infofromMainMc.Def.ToString();
                this.MonPicBox.Image = infofromMainMc.cardImage;
            }
        }//弃用



        static string Levelstar(int level)
        {
            string s = "";
            for(int i=0;i<level;i++)
            {
                s += "★";
            }
            return s;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            if(CardType==CardType.Mon_Card)
            {
                if(fromHandCardMc.Call(Player)==Mon_Card.CallResult.Success)
                {
                    if (Player.mon_Place.MonCall(fromHandCardMc) == Mon_Place.CallResult.Success)
                    {                      
                        button1.Hide();
                        this.NameLabel1.Text = "";
                        this.LevelLabel.Text = "";
                        this.DescriptionTextBox.Text = "召唤" + fromHandCardMc.Name + "成功";
                        this.AttLabel.Text = "ATT: " + "";
                        this.DefLabel.Text = "DEF: " + "";
                        this.MonPicBox.Image = Image.FromFile(".\\pic\\pic_called.jpg");
                        Player.HandCardController.OneCardGiveOut(fromHandCardMc);
                        Player.CardGroupForm.Renew();
                    }
                    else if((Player.mon_Place.MonCall(fromHandCardMc) == Mon_Place.CallResult.Full))
                    {
                        this.DescriptionTextBox.Text ="槽位已满";
                    }

                }
                this.Player.OriginalCallRest--;
                if(this.Player.OriginalCallRest==0)
                {
                    this.button1.Hide();
                }
            }
        }
        //---------------------------------------------------------------------------------------
        public void FromMonPlaceSelect(Mon_Card mc)//从怪物场上获得信息
        {
            this.fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selcetFromMonPlace_Mc = new Mon_null();
            fromGaveCard = new Mon_null();

            selcetFromMonPlace_Mc = mc;
            button1.Hide();
            button2.Hide();
            button3.Hide();
            if (mc is Mon_null)//若是空怪物
            {
                selcetFromMonPlace_Mc = mc;
                this.NameLabel1.Text = selcetFromMonPlace_Mc.GiveCardState()+selcetFromMonPlace_Mc.Name;
                this.LevelLabel.Text = Levelstar(selcetFromMonPlace_Mc.Level);
                this.DescriptionTextBox.Text = selcetFromMonPlace_Mc.Description;
                this.AttLabel.Text = "ATT: " + selcetFromMonPlace_Mc.Att.ToString();
                this.DefLabel.Text = "DEF: " + selcetFromMonPlace_Mc.Def.ToString();
                this.MonPicBox.Image = selcetFromMonPlace_Mc.cardImage;
                button2.Text = selcetFromMonPlace_Mc.Name + " 攻击";
            }
            else//不是空则
            {
                this.NameLabel1.Text = selcetFromMonPlace_Mc.GiveCardState() + selcetFromMonPlace_Mc.Name;
                this.LevelLabel.Text = Levelstar(selcetFromMonPlace_Mc.Level);
                this.DescriptionTextBox.Text = selcetFromMonPlace_Mc.Description;
                this.AttLabel.Text = "ATT: " + selcetFromMonPlace_Mc.Att.ToString();
                this.DefLabel.Text = "DEF: " + selcetFromMonPlace_Mc.Def.ToString();
                this.MonPicBox.Image = selcetFromMonPlace_Mc.cardImage;
                button2.Text = selcetFromMonPlace_Mc.Name + " 攻击";
                Button2ShowWithRequest();
                Button3ShowWithRequest();

            }
        }

        public void FromGraveSelect(Card card)//从墓地获取信息
        {
            fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selcetFromMonPlace_Mc = new Mon_null();
            fromGaveCard = new Mon_null();
            fromGaveCard = card;
            button1.Hide();
            button2.Hide();
            button3.Hide();
            if (card is Mon_Card)//如果是怪物卡
            {
                Mon_Card mc = (Mon_Card)fromGaveCard;
                if (card is Mon_null)//若是空怪物
                {
                    this.NameLabel1.Text = mc.GiveCardState()+mc.Name ;
                    this.LevelLabel.Text = Levelstar(mc.Level);
                    this.DescriptionTextBox.Text = mc.Description;
                    this.AttLabel.Text = "ATT: " + mc.Att.ToString();
                    this.DefLabel.Text = "DEF: " + mc.Def.ToString();
                    this.MonPicBox.Image = mc.cardImage;
                    button2.Text = mc.Name + " 攻击";
                }
                else//不是空则
                {
                    this.NameLabel1.Text = mc.GiveCardState() + mc.Name;
                    this.LevelLabel.Text = Levelstar(mc.Level);
                    this.DescriptionTextBox.Text = mc.Description;
                    this.AttLabel.Text = "ATT: " + mc.Att.ToString();
                    this.DefLabel.Text = "DEF: " + mc.Def.ToString();
                    this.MonPicBox.Image = mc.cardImage;
                    button2.Text = mc.Name + " 攻击";
                    Button2ShowWithRequest();
                    Button3ShowWithRequest();
                }
            }


        }

        //攻击指令拉起一个等待进程
        private void Button2_Click(object sender, EventArgs e)
        {
            if(selcetFromMonPlace_Mc is Mon_null)
            {
                return;
            }
            
            if(selcetFromMonPlace_Mc.AttAllow_Rest>0)
            {
                AttackChoose attackChooseForm = new AttackChoose(selcetFromMonPlace_Mc);
                attackChooseForm.ShowDialog();
            }
            button2.Hide();//攻击指令
            button3.Hide();
        }//攻击键



        public void RenewLocation()
        {
            if (this.Player == Player.MainPlaceInfo.Player1)
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.X -= this.Width;
                this.Location = point;

            }
            else
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.X += this.Player.MainPlaceInfo.MainFightPlace.Width;
                this.Location = point;
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            if (selcetFromMonPlace_Mc.State == CardState.State_Att& selcetFromMonPlace_Mc.ChangeStateRest>0)
            {
                selcetFromMonPlace_Mc.State = CardState.State_Def;
                FromMonPlaceSelect(selcetFromMonPlace_Mc);
                selcetFromMonPlace_Mc.ChangeStateRest--;
                button2.Hide();
            }
            else if(selcetFromMonPlace_Mc.State == CardState.State_Def & selcetFromMonPlace_Mc.ChangeStateRest > 0)
            {
                selcetFromMonPlace_Mc.State = CardState.State_Att;
                FromMonPlaceSelect(selcetFromMonPlace_Mc);
                selcetFromMonPlace_Mc.ChangeStateRest--;
                Button2ShowWithRequest();
            }
            button3.Hide();
        }//状态改变键

        public void Button2ShowWithRequest()//攻击键的带条件展示。
        {
            button2.Hide();
            if (selcetFromMonPlace_Mc is Mon_null)
            {
                return;
            }
            if (this.Player.Active & this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Fight)
            {

                if (selcetFromMonPlace_Mc.State == CardState.State_Att && selcetFromMonPlace_Mc.AttAllow_Rest > 0)
                {
                    button2.Show();//攻击指令
                }
            }
        }

        public void Button3ShowWithRequest()//修改攻守状态键的带条件展示。
        {
            button3.Hide();
            if (selcetFromMonPlace_Mc is Mon_null)
            {
                return;
            }
            if (this.Player.Active & (this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Main_1
                | this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Main_2))
            {

                if (selcetFromMonPlace_Mc.ChangeStateRest>0)
                {
                    button3.Show();//改变状态指令
                }
            }
        }

        public void InformRenew()
        {
            button1.Hide();
            button2.Hide();
            button3.Hide();
        }

    }
}
