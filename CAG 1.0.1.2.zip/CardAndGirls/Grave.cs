﻿using CardAndGirls.CardBag;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls
{
    public class Grave
    {
        public Player Player { get; set; }
        public List<Card> graveCards = new List<Card>();
    }
}
