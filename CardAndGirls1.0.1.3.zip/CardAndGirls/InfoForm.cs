﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CardAndGirls.CardBag;
using CardAndGirls.CardBag.MgcPitCard;
using static CardAndGirls.CardBag.Card;

namespace CardAndGirls
{
    
    public partial class InfoForm : Form
    {    
        public Player Player { get; set; }
        CardPicShowForm showForm = new CardPicShowForm();

        public Card SelectCard = new Card();
        public Mon_Card fromHandCardMc;
        public MgcPit_Card fromHandCardMPc;
        public Mon_Card infofromMainMc;
        public Mon_Card selectFromMonPlace_Mc;
        public MgcPit_Card selectFromMgcPitPlace_Mpc;
        public Card fromGaveCard;
        public CardType CardType;

        public InfoForm()
        {
            fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selectFromMonPlace_Mc= new Mon_null();
            fromGaveCard= new Mon_null();
            InitializeComponent();
            
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click_1(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 刷新Inform窗体位置
        /// </summary>
        public void RenewLocation()
        {
            if (this.Player == Player.MainPlaceInfo.Player1)
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.X -= this.Width;
                this.Location = point;

            }
            else
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.X += this.Player.MainPlaceInfo.MainFightPlace.Width;
                this.Location = point;
            }
        }
        static string Levelstar(int level)
        {
            string s = "";
            for (int i = 0; i < level; i++)
            {
                s += "★";
            }
            return s;
        }
        private void InfoForm_Load(object sender, EventArgs e)
        {
            HideAllButton();
            //位置跟随决斗盘
            if (this.Player == Player.MainPlaceInfo.Player1)
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.X -= this.Width;
                this.Location = point;
                
            }
            else
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.X += this.Player.MainPlaceInfo.MainFightPlace.Width;
                this.Location = point;

            }
            this.Text = Player.Name;
            
            
        }
        /// <summary>
        /// 隐藏所有按钮
        /// </summary>
        public void HideAllButton()
        {
            button1.Hide();
            button2.Hide();
            button3.Hide();
            button4.Hide();
        }

        private void MonPicBox_MouseHover(object sender, EventArgs e)
        {

            showForm.BackgroundImage = this.MonPicBox.Image;
            Point offset = this.Location;
            offset.Offset(this.Width + this.Player.MainPlaceInfo.MainFightPlace.Width / 2 - showForm.Width / 2, this.Player.MainPlaceInfo.MainFightPlace.Height / 2 - showForm.Height / 2);
            showForm.Location = offset;
            showForm.Show();
        }

        private void MonPicBox_MouseLeave(object sender, EventArgs e)
        {
            showForm.Hide();
        }

        //-------------------------------------------------------------------------------------------------






        [Obsolete]
        public void GetInfoFromCardFromMainPlace(Card card)
        {
            button1.Hide();
            button2.Hide();
            button3.Hide();
            fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selectFromMonPlace_Mc = new Mon_null();
            fromGaveCard = new Mon_null();
            if (card is Mon_Card)
            {
                infofromMainMc = (Mon_Card)card;
                this.NameLabel1.Text = infofromMainMc.Name + infofromMainMc.GiveCardState();
                infofromMainMc = new Mon_null();
                selectFromMonPlace_Mc = new Mon_null();
                fromGaveCard = new Mon_null(); ;
                this.LevelLabel.Text = Levelstar(infofromMainMc.Level);
                this.DescriptionTextBox.Text = infofromMainMc.Description;
                this.AttLabel.Text = "ATT: " + infofromMainMc.Att.ToString();
                this.DefLabel.Text = "DEF: " + infofromMainMc.Def.ToString();
                this.MonPicBox.Image = infofromMainMc.cardImage;
            }
        }




        /// <summary>
        /// 从【手牌】获取信息
        /// </summary>
        /// 判断为何种卡
        /// <param name="card"></param>
        public void FromHandCardSelect(Card card)
        {
            HideAllButton();
            fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selectFromMonPlace_Mc = new Mon_null();
            fromGaveCard = new Mon_null();
            fromHandCardMPc = new MgcPit_null();
            if (card is Mon_Card)
            {
                fromHandCardMc=(Mon_Card)card;
                this.NameLabel1.Text = fromHandCardMc.GiveCardState()+ fromHandCardMc.Name;
                this.LevelLabel.Text = Levelstar(fromHandCardMc.Level);
                this.DescriptionTextBox.Text = fromHandCardMc.Description;
                this.AttLabel.Text = "ATT: " + fromHandCardMc.Att.ToString();
                this.DefLabel.Text = "DEF: " + fromHandCardMc.Def.ToString();
                this.MonPicBox.Image = fromHandCardMc.cardImage;
                button1.Text = "召唤" + fromHandCardMc.Name;
                CardType = CardType.Mon_Card;
                Button1ShowWithRequest();
            }
            else if(card is MgcPit_Card)
            {
                fromHandCardMPc = (MgcPit_Card)card;
                this.NameLabel1.Text = fromHandCardMPc.GiveCardState() + fromHandCardMPc.Name;
                this.LevelLabel.Text = "";
                this.DescriptionTextBox.Text = fromHandCardMPc.Description;
                this.AttLabel.Text = "";
                this.DefLabel.Text = "";
                if(card is Mgc_Card)
                {
                    CardType = CardType.Mgc_Card;
                }
                else if(card is MgcPit_Card)
                {
                    CardType = CardType.Pit_Card;
                }
                this.MonPicBox.Image = fromHandCardMPc.cardImage;
                Button4ShowWithRequest();
            }


        }
   
        /// <summary>
        /// 当怪物被从【怪物场地】选择后：
        /// </summary>
        /// 此方法通常被MainFightPlace调用，用于给出从怪物场上获得的信息
        /// 此方法主要判断选择的怪物可否进行相应的操作（包括按钮显示的时机）
        /// 首先判断是否是空怪物
        /// 若不是则调用其他按钮显示条件函数，用于按钮显示的限制
        /// <param name="mc"></param>
        public void FromMonPlaceSelect(Mon_Card mc)
        {
            /*this.fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selcetFromMonPlace_Mc = new Mon_null();
            fromGaveCard = new Mon_null();*/

            selectFromMonPlace_Mc = mc;
            HideAllButton();
            if (mc is Mon_null)//若是空怪物
            {
                selectFromMonPlace_Mc = mc;
                this.NameLabel1.Text = selectFromMonPlace_Mc.GiveCardState()+selectFromMonPlace_Mc.Name;
                this.LevelLabel.Text = Levelstar(selectFromMonPlace_Mc.Level);
                this.DescriptionTextBox.Text = selectFromMonPlace_Mc.Description;
                this.AttLabel.Text = "ATT: " + selectFromMonPlace_Mc.Att.ToString();
                this.DefLabel.Text = "DEF: " + selectFromMonPlace_Mc.Def.ToString();
                this.MonPicBox.Image = selectFromMonPlace_Mc.cardImage;
                button2.Text = selectFromMonPlace_Mc.Name + " 攻击";
            }
            else//不是空则
            {
                this.NameLabel1.Text = selectFromMonPlace_Mc.GiveCardState() + selectFromMonPlace_Mc.Name;
                this.LevelLabel.Text = Levelstar(selectFromMonPlace_Mc.Level);
                this.DescriptionTextBox.Text = selectFromMonPlace_Mc.Description;
                this.AttLabel.Text = "ATT: " + selectFromMonPlace_Mc.Att.ToString();
                this.DefLabel.Text = "DEF: " + selectFromMonPlace_Mc.Def.ToString();
                this.MonPicBox.Image = selectFromMonPlace_Mc.cardImage;
                button2.Text = selectFromMonPlace_Mc.Name + " 攻击";
                Button2ShowWithRequest();
                Button3ShowWithRequest();

            }
        }
        /// <summary>
        /// 当怪物被从魔法陷阱卡区域选择后
        /// </summary>
        /// <param name="mgc"></param>
        public void FromMgcPitPlaceSelect(MgcPit_Card mgc)
        {
            selectFromMgcPitPlace_Mpc = mgc;
            HideAllButton();
            if (mgc is MgcPit_null)//若是空区域
            {
                selectFromMgcPitPlace_Mpc = mgc;
                this.NameLabel1.Text = selectFromMgcPitPlace_Mpc.GiveCardState() + selectFromMgcPitPlace_Mpc.Name;
                this.LevelLabel.Text = "";
                this.DescriptionTextBox.Text = selectFromMgcPitPlace_Mpc.Description;
                this.AttLabel.Text = "";
                this.DefLabel.Text = "";
                this.MonPicBox.Image = selectFromMgcPitPlace_Mpc.cardImage;
                
            }
            else//不是空则
            {
                this.NameLabel1.Text = selectFromMgcPitPlace_Mpc.GiveCardState() + selectFromMgcPitPlace_Mpc.Name;
                this.LevelLabel.Text = "";
                this.DescriptionTextBox.Text = selectFromMgcPitPlace_Mpc.Description;
                this.AttLabel.Text = "";
                this.DefLabel.Text = "";
                this.MonPicBox.Image = selectFromMgcPitPlace_Mpc.cardImage;
                
            }
        }

        /// <summary>
        /// 从【墓地】获取卡片信息
        /// </summary>
        /// 判断是什么类型的卡，再调用按钮显示函数（带条件的）
        /// <param name="card"></param>
        public void FromGraveSelect(Card card)
        {
            fromHandCardMc = new Mon_null();
            infofromMainMc = new Mon_null();
            selectFromMonPlace_Mc = new Mon_null();
            fromGaveCard = new Mon_null();
            fromGaveCard = card;
            button1.Hide();
            button2.Hide();
            button3.Hide();
            if (card is Mon_Card)//如果是怪物卡
            {
                Mon_Card mc = (Mon_Card)fromGaveCard;
                if (card is Mon_null)//若是空怪物
                {
                    this.NameLabel1.Text = mc.GiveCardState()+mc.Name ;
                    this.LevelLabel.Text = Levelstar(mc.Level);
                    this.DescriptionTextBox.Text = mc.Description;
                    this.AttLabel.Text = "ATT: " + mc.Att.ToString();
                    this.DefLabel.Text = "DEF: " + mc.Def.ToString();
                    this.MonPicBox.Image = mc.cardImage;
                    button2.Text = mc.Name + " 攻击";
                }
                else//不是空则
                {
                    this.NameLabel1.Text = mc.GiveCardState() + mc.Name;
                    this.LevelLabel.Text = Levelstar(mc.Level);
                    this.DescriptionTextBox.Text = mc.Description;
                    this.AttLabel.Text = "ATT: " + mc.Att.ToString();
                    this.DefLabel.Text = "DEF: " + mc.Def.ToString();
                    this.MonPicBox.Image = mc.cardImage;
                    button2.Text = mc.Name + " 攻击";
                    Button2ShowWithRequest();
                    Button3ShowWithRequest();
                }
            }


        }


        /// <summary>
        /// 【召唤按钮】被按下时候
        /// </summary>
        /// 召唤按钮按下后：
        /// 对什么卡起效，起什么效果
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button1_Click(object sender, EventArgs e)
        {

            if (CardType == CardType.Mon_Card)
            {
                if (fromHandCardMc.Call(Player) == Mon_Card.CallResult.Success)
                {
                    if (Player.mon_Place.MonCall(fromHandCardMc) == Mon_Place.CallResult.Success)
                    {
                        button1.Hide();
                        this.NameLabel1.Text = "";
                        this.LevelLabel.Text = "";
                        this.DescriptionTextBox.Text = "召唤" + fromHandCardMc.Name + "成功";
                        this.AttLabel.Text = "ATT: " + "";
                        this.DefLabel.Text = "DEF: " + "";
                        this.MonPicBox.Image = Image.FromFile(".\\pic\\pic_called.jpg");
                        Player.HandCardController.OneCardGiveOut(fromHandCardMc);
                        Player.CardGroupForm.Renew();
                    }
                    else if ((Player.mon_Place.MonCall(fromHandCardMc) == Mon_Place.CallResult.Full))
                    {
                        this.DescriptionTextBox.Text = "槽位已满";
                    }

                }
                this.Player.OriginalCallRest--;
                if (this.Player.OriginalCallRest == 0)
                {
                    this.button1.Hide();
                }
            }
        }
        
        /// <summary>
        /// 【攻击按钮】被按下时
        /// </summary>
        /// 先判断是否是空怪物，是则直接返回
        /// 否则判断怪物攻击宣言的剩余次数
        /// 可以攻击则唤起可攻击的列表
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button2_Click(object sender, EventArgs e)
        {
            if(selectFromMonPlace_Mc is Mon_null)
            {
                return;
            }
            
            if(selectFromMonPlace_Mc.AttAllow_Rest>0)
            {
                AttackChoose attackChooseForm = new AttackChoose(selectFromMonPlace_Mc);
                attackChooseForm.ShowDialog();
            }
            button2.Hide();//攻击指令
            button3.Hide();
        }
       
        /// <summary>
        /// 【状态改变按钮】被按下时
        /// </summary>
        /// 判断怪物攻守状态，改变状态
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button3_Click(object sender, EventArgs e)
        {
            if (selectFromMonPlace_Mc.State == CardState.State_Att& selectFromMonPlace_Mc.ChangeStateRest>0)
            {
                selectFromMonPlace_Mc.State = CardState.State_Def;
                FromMonPlaceSelect(selectFromMonPlace_Mc);
                selectFromMonPlace_Mc.ChangeStateRest--;
                button2.Hide();
            }
            else if(selectFromMonPlace_Mc.State == CardState.State_Def & selectFromMonPlace_Mc.ChangeStateRest > 0)
            {
                selectFromMonPlace_Mc.State = CardState.State_Att;
                FromMonPlaceSelect(selectFromMonPlace_Mc);
                selectFromMonPlace_Mc.ChangeStateRest--;
                Button2ShowWithRequest();
            }
            button3.Hide();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            if(CardType == CardType.Mgc_Card)
            {
                if (fromHandCardMPc.BackSet() == Mon_Card.CallResult.Success)
                {
                    if (Player.MgcPit_Place. MgcPitBackSet(fromHandCardMPc)== MgcPit_Place.CallResult.Success)
                    {
                        button4.Hide();
                        this.NameLabel1.Text = "";
                        this.LevelLabel.Text = "";
                        this.DescriptionTextBox.Text = "埋伏" + fromHandCardMPc.Name + "成功";
                        this.AttLabel.Text = "";
                        this.DefLabel.Text = "";
                        this.MonPicBox.Image = Image.FromFile(".\\pic\\pic_called.jpg");
                        Player.HandCardController.OneCardGiveOut(fromHandCardMPc);
                        Player.CardGroupForm.Renew();
                    }
                    else if ((Player.MgcPit_Place.MgcPitBackSet(fromHandCardMPc) == MgcPit_Place.CallResult.Full))
                    {
                        this.DescriptionTextBox.Text = "槽位已满";
                    }

                }
            }
        }

        /// <summary>
        /// 【召唤按钮】显示（自判断）
        /// </summary>
        public void Button1ShowWithRequest()
        {
            button1.Hide();
            if (((this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Main_1) | (this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Main_2)) && this.Player.Active)
            {
                if (this.Player.OriginalCallRest > 0)
                {
                    button1.Show();
                }

            }
        }

        /// <summary>
        /// 【攻击键】显示（自判断）
        /// </summary>
        public void Button2ShowWithRequest()//攻击键的带条件展示。
        {
            button2.Hide();
            if (selectFromMonPlace_Mc.Player == this.Player.MainPlaceInfo.ActivePlayer)
            {
                if (selectFromMonPlace_Mc is Mon_null)
                {
                    return;
                }
                if (this.Player.Active & this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Fight)
                {

                    if (selectFromMonPlace_Mc.State == CardState.State_Att && selectFromMonPlace_Mc.AttAllow_Rest > 0)
                    {
                        button2.Show();//攻击指令
                    }
                }
            }

        }
        /// <summary>
        /// 【改变状态】显示（自判断）
        /// </summary>
        public void Button3ShowWithRequest()//修改攻守状态键的带条件展示。
        {
            button3.Hide();
            if (selectFromMonPlace_Mc.Player == this.Player.MainPlaceInfo.ActivePlayer)
            {
                if (selectFromMonPlace_Mc is Mon_null)
                {
                    return;
                }
                if (this.Player.Active & (this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Main_1
                    | this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Main_2))
                {

                    if (selectFromMonPlace_Mc.ChangeStateRest > 0)
                    {
                        button3.Show();//改变状态指令
                    }
                }
            }
        }

        public void Button4ShowWithRequest()
        {
            button4.Hide();
            if (fromHandCardMPc.Player == this.Player.MainPlaceInfo.ActivePlayer)
            {
                if (fromHandCardMPc is MgcPit_null)
                {
                    return;
                }
                if (this.Player.Active & (this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Main_1
                    | this.Player.MainPlaceInfo.process == MainPlaceInfo.Process.Main_2))
                {
                    button4.Show();
                }
            }
        }




    }
}
