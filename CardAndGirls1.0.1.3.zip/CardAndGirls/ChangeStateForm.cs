﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CardAndGirls
{
    public partial class ChangeStateForm : Form
    {
        public ChangeStateForm()
        {
            InitializeComponent();
        }

        private void ChangeStateForm_Load(object sender, EventArgs e)
        {

        }
    }
}
