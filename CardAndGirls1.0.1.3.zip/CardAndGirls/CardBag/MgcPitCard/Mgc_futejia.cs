﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls.CardBag.MgcPitCard
{
    class Mgc_futejia : Mgc_Card
    {
        public Mgc_futejia()
        {
            base.Name = "伏特加";
            base.cardImage = Image.FromFile(".\\pic\\Magic_pic\\magic_futejia.png");
            base.Description = "①：本回合自己受到的伤害为0。\r\n\r\n“ ————吨吨吨……嗝” ";
        }

        public override void Effect()
        {
            //效果：本回合自己受到的伤害为0；
        }
    }
}
