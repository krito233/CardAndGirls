﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls.CardBag
{
    public class MgcPit_null:Mgc_Card
    {
        public MgcPit_null()
        {
            base.Name = "";
            base.cardImage = Image.FromFile(".\\pic\\pic_null.jpg");
            base.backSetImage= Image.FromFile(".\\pic\\pic_null.jpg");
        }
    }
}
