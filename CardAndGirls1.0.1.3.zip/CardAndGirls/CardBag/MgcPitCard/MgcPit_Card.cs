﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls.CardBag.MgcPitCard
{
    public class MgcPit_Card:Card
    {
        public Image backSetImage;
        public MgcPit_Card()
        {
            base.State = CardState.State_Null;
            backSetImage = Image.FromFile(".\\pic\\magic_backset.jpg");
        }

        public virtual void Effect()
        {

        }

        public virtual void Die()
        {
            this.State = CardState.State_InDom;
        }

        public virtual Mon_Card.CallResult BackSet()
        {
            return Mon_Card.CallResult.Success;
        }
    }

}
