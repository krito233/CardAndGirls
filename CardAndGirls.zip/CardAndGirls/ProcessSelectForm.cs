﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static CardAndGirls.MainPlaceInfo;

namespace CardAndGirls
{
    public partial class ProcessSelectForm : Form
    {
        public Player Player { get; set; }
        public ProcessSelectForm()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            this.Player.ProcessGoOn();
            this.Player.InfoForm.InformRenew();
        }

        private void ProcessSelectForm_Load(object sender, EventArgs e)
        {
            if (this.Player.Equals(this.Player.MainPlaceInfo.Player1))
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.Y += this.Player.MainPlaceInfo.MainFightPlace.Height + 5;
                this.Location = point;
            }
            else
            {
                Point point = this.Player.MainPlaceInfo.MainFightPlace.Location;
                point.Y += -this.Height - 5;
                point.X += this.Player.MainPlaceInfo.MainFightPlace.Width - this.Width;
                this.Location = point;
            }
        }

        private void Button2_Click(object sender, EventArgs e)//回合结束按钮
        {
            if(this.Player.MainPlaceInfo.Time!=0&&this.Player.MainPlaceInfo.process!=Process.GetCard)
            {
                this.Player.MainPlaceInfo.process = Process.End;
            }
           this.Player.InfoForm.InformRenew();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void TextRenew()
        {
            if(this.Player.MainPlaceInfo.Time==0)
            {
                return;
            }
            textBox1.Text = GameStateToString(this.Player.MainPlaceInfo.process);
        }
        public static string GameStateToString(Process n)
        {
            switch (n)
            {
                case Process.GetCard:
                    return "抽牌阶段";
                case Process.Preparation:
                    return "准备阶段";
                case Process.Main_1:
                    return "主要阶段1";
                case Process.Fight:
                    return "战斗阶段";
                case Process.FightRollBack:
                    return "战斗回滚阶段";
                case Process.Main_2:
                    return "主要阶段2";
                case Process.End:
                    return "结束阶段";
                case Process.GameStart:
                    return "双方抽取手牌";
                default:
                    return "";
            }
        }

    }
}
