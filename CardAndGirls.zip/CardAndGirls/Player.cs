﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static CardAndGirls.MainPlaceInfo;

namespace CardAndGirls
{
    public class Player
    {
        public int Hp { get; set; }
        public string Name { get; set; }
        public Mon_Place mon_Place = new Mon_Place();


        public MainPlaceInfo MainPlaceInfo { get; set; }
        public CardGroup CardGroup { get; set; }
        public HandCardController HandCardController { get; set; }
        public Grave Grave { get; set; }
        public Info Info { get; set; }
        public CardGroupForm CardGroupForm { get; set; }
        public InfoForm InfoForm { get; set; }
        public Player OpPlayer { get; set; }
        public ProcessSelectForm ProcessSelectForm { get; set; }

        //------------------------------对局信息
        public bool Active { get; set; }

        public bool GetFiveCardAlready { get; set; }
        public int GetCardLimit { get; set; }
        public int GetCardRest { get; set; }
        public int OriginalCallLimit { get; set; }
        public int OriginalCallRest { get; set; } 



        //-----------------------------
        

        public Player()
        {
            Hp = 4000;
            Active = false;
            GetFiveCardAlready = false;
            GetCardLimit = 1;
            GetCardRest = 1;
            OriginalCallLimit = 1;
            OriginalCallRest = 1;
        }
        public Player(string name)
        {
            
            Name = name;
            Hp = 4000;
            Active = false;
            GetFiveCardAlready = false;
            GetCardLimit = 1;
            GetCardRest = 1;
            OriginalCallLimit = 1;
            OriginalCallRest = 1;
        }

        public void TimeEnd()
        {
            PlayerIntoNewTime();
            this.MainPlaceInfo.process = Process.GetCard;
            for(int i=0;i<5;i++)
            {
                this.mon_Place.place[i].Mon_Renew();
            }
            
            this.MainPlaceInfo.TimePlusOne();
        }

        public void ProcessGoOn()
        {
            if (this.Active)
            {
                switch (this.MainPlaceInfo.process)
                {
                    case Process.GetCard:
                        if (this.GetCardRest > 0)
                        {
                            this.MainPlaceInfo.MainFightPlace.textBox3.Text = "未进行抽卡,无法进入下一流程";
                        }
                        else if (this.GetCardRest == 0)
                        {
                            this.MainPlaceInfo.process = Process.Preparation;
                        }
                        break;
                    case Process.Preparation:
                        this.MainPlaceInfo.process = Process.Main_1;
                        break;
                    case Process.Main_1:
                        this.MainPlaceInfo.process = Process.Fight;
                        break;
                    case Process.Fight:
                        this.MainPlaceInfo.process = Process.FightRollBack;
                        break;
                    case Process.FightRollBack:
                        this.MainPlaceInfo.process = Process.Main_2;
                        break;
                    case Process.Main_2:
                        this.MainPlaceInfo.process = Process.End;
                        break;
                    case Process.End:
                        this.MainPlaceInfo.process = Process.GetCard;
                        TimeEnd();
                        break;
                    case Process.GameStart:

                        break;
                    default:
                        break;
                }
            }
        }

        public void PlayerRenew()
        {
            switch (this.MainPlaceInfo.process)
            {
                case Process.GetCard:
                    {
                        
                        if (this.Equals(MainPlaceInfo.ActivePlayer))
                        {
                            
                            if (this.GetCardRest > 0)
                            {
                                this.CardGroupForm.GetOne.Show();
                            }
                            else if (this.GetCardRest == 0)
                            {
                                this.CardGroupForm.GetOne.Hide();
                            }

                        }
                    }
                    break;
                case Process.Preparation:
                    {

                    }
                    break;
                case Process.Main_1:
                    {
                        if (this.Equals(MainPlaceInfo.ActivePlayer))
                        {
                            if (this.OriginalCallRest > 0)
                            {
                                this.InfoForm.button1.Show();
                            }
                            else if (this.OriginalCallRest == 0)
                            {
                                this.InfoForm.button1.Hide();
                            }

                        }
                    }
                    break;
                case Process.Fight:
                    {
                        if (this.Equals(MainPlaceInfo.ActivePlayer))
                        {

                        }
                    }
                    break;
                case Process.FightRollBack:
                    break;
                case Process.Main_2:
                    {
                        if (this.Equals(MainPlaceInfo.ActivePlayer))
                        {
                            if (this.OriginalCallRest > 0)
                            {
                                this.InfoForm.button1.Show();
                            }
                            else if (this.OriginalCallRest == 0)
                            {
                                this.InfoForm.button1.Hide();
                            }

                        }
                    }
                    break;
                case Process.End:
                    break;
                case Process.GameStart:
                    break;
                default:
                    break;
            }
        }


        public void PlayerIntoNewTime()
        {
            Active = false;
            GetCardRest = GetCardLimit;
            OriginalCallRest = OriginalCallLimit;
        }

    }
}
