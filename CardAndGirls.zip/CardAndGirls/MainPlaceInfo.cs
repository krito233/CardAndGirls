﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls
{
    public class MainPlaceInfo
    {
        public MainFightPlace MainFightPlace { get; set; }
        public Player Player1 { get; set; }
        public Player Player2 { get; set; }

        public Player ActivePlayer { get; set; }
        public int Time { get; set; }

        public GameState gameState;

        public Process process;


        [Description("流程状态")]
        public enum Process
        {
            [Description("抽卡阶段")]
            GetCard,
            [Description("准备阶段")]
            Preparation,
            [Description("主要阶段1")]
            Main_1,
            [Description("战斗阶段")]
            Fight,
            [Description("战斗回滚")]
            FightRollBack,
            [Description("主要阶段2")]
            Main_2,
            [Description("结束阶段")]
            End,
            [Description("开局抽牌阶段")]
            GameStart
        }
        [Description("游戏状态")]
        public enum GameState
        {
            
            Player1Win,
            Player2Win,
            Process
        }

        public static string GameStateToString(Process n)
        {
            switch (n)
            {
                case Process.GetCard:
                    return "抽牌阶段";
                case Process.Preparation:
                    return "准备阶段";
                case Process.Main_1:
                    return "主要阶段1";
                case Process.Fight:
                    return "战斗阶段";
                case Process.FightRollBack:
                    return "战斗回滚阶段";
                case Process.Main_2:
                    return "主要阶段2";
                case Process.End:
                    return "结束阶段";
                case Process.GameStart:
                    return "双方抽取手牌";
                default:
                    return "";
            }
        }
        

        public MainPlaceInfo()
        {
            this.Time = 0;
            this.gameState = GameState.Process;
            this.process = Process.GameStart;
        }

        public void TimePlusOne()
        {
            Time++;
        }
        
        public GameState GamStateFormMainInfo()
        {

            if (Player1.Hp <= 0)
            {
                this.gameState = GameState.Player2Win;
                return GameState.Player2Win;
            }
            else if(Player2.Hp <= 0)
            {
                this.gameState = GameState.Player1Win;
                return GameState.Player1Win;
            }
            else
            {
                return GameState.Process;
            }
        }


        public void GameGoing()
        {          
            
            if(gameState == GameState.Process)//说明游戏还在进行
            {
                if(Time==0)
                {
                    
                }
                else if(Time%2==0)
                {
                    Player2.Active = true;
                    Player1.Active = false;
                    ActivePlayer = Player2;
                }
                else if(Time % 2 == 1 )
                {
                    Player1.Active = true;
                    Player2.Active = false;
                    ActivePlayer = Player1;
                }
                switch (this.process)
                {
                    case Process.GetCard:
                        {
                            this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合[" + ActivePlayer.Name + "]    抽牌阶段";
                        }
                        break;
                    case Process.Preparation:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合" + "       " + "准备阶段";
                        break;
                    case Process.Main_1:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合" + "       " + "主要阶段1";
                        break;
                    case Process.Fight:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合" + "       " + "战斗阶段";
                        break;
                    case Process.FightRollBack:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合" + "       " + "战斗回滚阶段";
                        break;
                    case Process.Main_2:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合" + "       " + "主要阶段2";
                        break;
                    case Process.End:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合" + "       " + "结束阶段";
                        break;
                    case Process.GameStart:
                        {
                            this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合" + "       " + "双方抽取手牌";
                            if(Player1.GetFiveCardAlready&&Player2.GetFiveCardAlready)
                            {
                                TimePlusOne();
                                this.process = Process.GetCard;
                            }
                        }
                        break;
                    default:
                        break;
                }


            }
            
        }




    }
}
