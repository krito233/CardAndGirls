﻿using CardAndGirls.CardBag;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls
{
    public class MainPlaceInfo
    {
        public MainFightPlace MainFightPlace { get; set; }
        public Player Player1 { get; set; }
        public Player Player2 { get; set; }
        public ParentForm ParentForm { get; set; }
        //public TriggerAndCatch TriggerAndCatch{get;set ;}
        public Player ActivePlayer { get; set; }
        /// <summary>
        /// 触发捕获委托
        /// </summary>
        /// <param name="card"></param>
        /// 用来传递玩家是否在阻塞后进行操作
        /// <returns></returns>
        public delegate bool Catch(Card card);
        public delegate bool Catch_EffectOn(IHaveEffect Ecard);
        

        public int Time { get; set; }

        public GameState gameState;

        public Process process;


        [Description("流程状态")]
        public enum Process
        {
            [Description("抽卡阶段")]
            GetCard,
            [Description("准备阶段")]
            Preparation,
            [Description("主要阶段1")]
            Main_1,
            [Description("战斗阶段")]
            Fight,
            [Description("战斗回滚")]
            FightRollBack,
            [Description("主要阶段2")]
            Main_2,
            [Description("结束阶段")]
            End,
            [Description("开局抽牌阶段")]
            GameStart
        }
        [Description("游戏状态")]
        public enum GameState
        {

            Player1Win,
            Player2Win,
            Process
        }

        public static string GameStateToString(Process n)
        {
            switch (n)
            {
                case Process.GetCard:
                    return "抽牌阶段";
                case Process.Preparation:
                    return "准备阶段";
                case Process.Main_1:
                    return "主要阶段1";
                case Process.Fight:
                    return "战斗阶段";
                case Process.FightRollBack:
                    return "战斗回滚阶段";
                case Process.Main_2:
                    return "主要阶段2";
                case Process.End:
                    return "结束阶段";
                case Process.GameStart:
                    return "双方抽取手牌";
                default:
                    return "";
            }
        }


        public MainPlaceInfo()
        {
            this.Time = 0;
            this.gameState = GameState.Process;
            this.process = Process.GameStart;
            MainFightPlace = new MainFightPlace(this);


        }

        public void TimePlusOne()
        {
            Time++;
        }

        public GameState GamStateFormMainInfo()
        {
            if (Player1.CardGroup.cardList.Count == 0)
            {
                return GameState.Player2Win;
            }
            else if (Player1.CardGroup.cardList.Count == 0)
            {
                return GameState.Player1Win;
            }
            if (Player1.Hp <= 0)
            {
                this.gameState = GameState.Player2Win;
                return GameState.Player2Win;
            }
            else if (Player2.Hp <= 0)
            {
                this.gameState = GameState.Player1Win;
                return GameState.Player1Win;
            }
            else
            {
                return GameState.Process;
            }
        }


        public void GameGoing()
        {

            if (gameState == GameState.Process)//说明游戏还在进行
            {
                if (Time == 0)
                {

                }
                else if (Time % 2 == 0)
                {
                    Player2.Active = true;
                    Player1.Active = false;
                    ActivePlayer = Player2;
                }
                else if (Time % 2 == 1)
                {
                    Player1.Active = true;
                    Player2.Active = false;
                    ActivePlayer = Player1;
                }
                switch (this.process)
                {
                    case Process.GetCard:
                        {
                            this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合[" + ActivePlayer.Name + "]    抽牌阶段";
                        }
                        break;
                    case Process.Preparation:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合[" + ActivePlayer.Name + "]     准备阶段";
                        break;
                    case Process.Main_1:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合[" + ActivePlayer.Name + "]     主要阶段1";
                        break;
                    case Process.Fight:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合[" + ActivePlayer.Name + "]     战斗阶段";
                        break;
                    case Process.FightRollBack:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合[" + ActivePlayer.Name + "]     战斗回滚阶段";
                        break;
                    case Process.Main_2:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合[" + ActivePlayer.Name + "]     主要阶段2";
                        break;
                    case Process.End:
                        this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合[" + ActivePlayer.Name + "]     结束阶段";
                        break;
                    case Process.GameStart:
                        {
                            this.MainFightPlace.textBox4.Text = "第【" + Time + "】回合" + "       " + "双方抽取手牌";
                            if (Player1.GetFiveCardAlready && Player2.GetFiveCardAlready)
                            {
                                TimePlusOne();
                                this.process = Process.GetCard;
                            }
                        }
                        break;
                    default:
                        break;
                }


            }

        }
        //-------------------------------------------------------------------------------------------------
        /// <summary>
        /// 触发阻塞
        /// </summary>
        public bool Block(Card card, TriggerType typ)
        {
            //开始阻塞
            card.Player.Block();
            //用于记录阻塞是否结束
            bool temp=true;
            //开始循环判断是否还有阻塞
            while (temp==true)
            {
                //判断阻塞类型
                switch (typ)
                {
                    case TriggerType.Trigger_WhenAddToHandCard:

                        if (Catch_WhenAddToHandCard.Count != 0)
                        {
                            foreach (var item in Catch_WhenAddToHandCard)
                            {
                                if (item(card) == true)
                                {
                                    temp = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            temp = false;
                        }
                        break;
                    case TriggerType.Trigger_WhenAddToPlace:
                        MainFightPlace.textBox3.Text = card.Player.Name + "触发【加入场地】，等待阻塞";
                        if (Catch_WhenAddToHandCard.Count != 0)
                        {
                            foreach (var item in Catch_WhenAddToHandCard)
                            {
                                if (item(card) == true)
                                {
                                    temp = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            temp = false;
                        }
                        break;
                    case TriggerType.Trigger_WhenMonAttack:
                        if (Catch_WhenMonAttack.Count != 0)
                        {
                            foreach (var item in Catch_WhenMonAttack)
                            {
                                if (item(card) == true)
                                {
                                    temp = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            temp = false;
                        }
                        break;
                    case TriggerType.Trigger_WhenMonChangeState:
                        if (Catch_WhenMonChangeState.Count != 0)
                        {
                            foreach (var item in Catch_WhenMonChangeState)
                            {
                                if (item(card) == true)
                                {
                                    temp = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            temp = false;
                        }
                        break;
                    case TriggerType.Trigger_WhenEffectOn:
                        if (Catch_WhenEffectOn.Count != 0)
                        {
                            foreach (var item in Catch_WhenEffectOn)
                            {
                                if (item(card) == true)
                                {
                                    temp = true;
                                    break;
                                }
                            }
                        }
                        temp = false;
                        break;
                    case TriggerType.Trigger_WhenEffectBlock:
                        if (Catch_WhenEffectBlock.Count != 0)
                        {
                            foreach (var item in Catch_WhenEffectBlock)
                            {
                                if (item(card) == true)
                                {
                                    temp = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            temp = false;
                        }
                        break;
                    case TriggerType.Trigger_WhenLeavePlace:
                        if (Catch_WhenLeavePlace.Count != 0)
                        {
                            foreach (var item in Catch_WhenLeavePlace)
                            {
                                if (item(card) == true)
                                {
                                    temp = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            temp = false;
                        }
                        break;
                    case TriggerType.Trigger_WhenAddToGrave:
                        if (Catch_WhenAddToGrave.Count != 0)
                        {
                            foreach (var item in Catch_WhenAddToGrave)
                            {
                                if (item(card) == true)
                                {
                                    temp = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            temp = false;
                        }
                        break;
                    case TriggerType.Trigger_WhenAddToException:
                        if (Catch_WhenAddToException.Count != 0)
                        {
                            foreach (var item in Catch_WhenAddToException)
                            {
                                if (item(card) == true)
                                {
                                    temp = true;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            temp = false;
                        }
                        break;
                    default:
                        temp = false;
                        break;
                }
            }
           
            //解除阻塞
            card.Player.Unblock();
            MainFightPlace.textBox3.Text = card.Player.Name + "  的阻塞"+typ+"结束，请继续操作";
            return temp;

        }

        public void Block_WhenEffectOn(Card Ecard)
        {
            bool temp = true;
            while(temp)
            {
                if(Catch_WhenEffectOn.Count>0)
                {
                     for(int i = 0; i < Catch_WhenEffectOn.Count; i++)
                    {
                        Catch_WhenEffectOn[i](Ecard);
                    }
                }
                else
                {
                    temp = false;
                }
            }
        }
        //注册列表
        public List<Catch> Catch_WhenAddToHandCard = new List<Catch>(5);      
        public List<Catch> Catch_WhenAddToPlace = new List<Catch>(5);
        public List<Catch> Catch_WhenMonAttack = new List<Catch>(5);
        public List<Catch> Catch_WhenMonChangeState = new List<Catch>(5);

        public List<Catch> Catch_WhenEffectOn = new List<Catch>(5);

        public List<Catch> Catch_WhenEffectBlock = new List<Catch>(5);
        public List<Catch> Catch_WhenLeavePlace = new List<Catch>(5);
        public List<Catch> Catch_WhenAddToGrave = new List<Catch>(5);
        public List<Catch> Catch_WhenAddToException = new List<Catch>(5);

        public enum TriggerType
        {
            Trigger_WhenAddToHandCard,
            Trigger_WhenAddToPlace,
            Trigger_WhenMonAttack,
            Trigger_WhenMonChangeState,
            Trigger_WhenEffectOn,
            Trigger_WhenEffectBlock,
            Trigger_WhenLeavePlace,
            Trigger_WhenAddToGrave,
            Trigger_WhenAddToException
        }
//----------------------------------------------------------------------------------------------------------------

    }
}
