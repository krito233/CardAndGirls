﻿using CardAndGirls.CardBag;
using CardAndGirls.CardBag.MgcPitCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls
{
    public class MgcPit_Place
    {
        public List<MgcPit_Card> place;

        public Player Player { get; set; }
        public enum CallResult
        {
            Success, Full
        }
        public MgcPit_null mgcPit_null= new MgcPit_null();
        public MgcPit_Place(Player player)
        {
            this.Player = player;
            mgcPit_null.Player = this.Player;
            place = new List<MgcPit_Card>(5);
            place.Add(mgcPit_null);
            place.Add(mgcPit_null);
            place.Add(mgcPit_null);
            place.Add(mgcPit_null);
            place.Add(mgcPit_null);
        }

        public CallResult MgcPitBackSet(MgcPit_Card mgc)
        {
            if (place.Contains(mgcPit_null))
            {
                int index = place.IndexOf(mgcPit_null);
                place[index] = mgc;
                place[index].firstBackSet = true;
                place[index].State = Card.CardState.State_BackSet;
                return CallResult.Success;
            }
            else
            {
                return CallResult.Full;
            }
        }
    }
}
