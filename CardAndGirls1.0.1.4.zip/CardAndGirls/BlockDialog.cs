﻿using CardAndGirls.CardBag;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static CardAndGirls.MainPlaceInfo;

namespace CardAndGirls
{
    public partial class BlockDialog : Form
    {
        Card trigger;
        IIsACatch catcher;
        TriggerType type;
        public BlockDialog(Card trigger,IIsACatch catcher,TriggerType type)
        {
            this.trigger = trigger;
            this.catcher = catcher;
            this.type = type;
            InitializeComponent();
        }

        private void BlockDialog_Load(object sender, EventArgs e)
        {
            this.textBox1.Text = "触发源类型：" + type + "\r\n触发源：" + trigger.Player.Name + "   " + trigger.Name
                + "\r\n捕获者：" + catcher.Player.Name + "   " + catcher.Name;
        }

        private void Button1_Click(object sender, EventArgs e)
        {

            catcher.ToBlock = true;
            this.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
