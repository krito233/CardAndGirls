﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls
{
    /// <summary>
    /// 有效果接口
    /// </summary>
    /// 对于有效果的卡片必须实现的内容
    public interface IHaveEffect
    {
        
        //用于记录是否被其他效果阻塞
        bool WhenEffectOn_BeBlocked { get; set; }

        IIsACatch Catcher { get; set; }
        //拥有效果
        void Effect();
        
        //用于实现被阻塞时的采取的操作
        void WhenEffectBlock(IIsACatch catcher);
    }
}
