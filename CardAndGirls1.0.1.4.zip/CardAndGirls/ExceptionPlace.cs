﻿using CardAndGirls.CardBag;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls
{
    public class ExceptionPlace
    {
        public Player Player { get; set; }
        public List<Card> ExceptionCards = new List<Card>();

        public ExceptionPlace(Player player)
        {
            this.Player = player;
        }
    }
}