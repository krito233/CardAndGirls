﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls.CardBag
{
    public class Card
    {
        public string Name { get; set; }
        public Image cardImage;
        public Player Player { get; set; }
        public string Description { get; set; }

        //被阻塞的原因
        public bool WhenAddToHandCard_BeBlocked { get; set; }
        public bool WhenAddToPlace_BeBlocked { get; set; }
        public bool WhenEffectOn_BeBlocked { get; set; }
        public bool WhenEffectBlock_BeBlocked { get; set; }
        public bool WhenLeavePlace_BeBlocked { get; set; }
        public bool WhenAddToGrave_BeBlocked { get; set; }
        public bool WhenAddToException_BeBlocked { get; set; }

        
        //-----------------------------------------------------------------------------------------
        public enum CardType 
        {
            Mon_Card,Mgc_Card,Pit_Card 
        }
        public CardType Type { get; set; }
        public CardState State { get; set; }
        
        
        //------------------------------------------------------------------------------------------
        public virtual string GiveCardState()
        {
            switch (State)
            {
                case CardState.State_Att:
                    return "[攻]";
                case CardState.State_Def:
                    return "[守]";
                case CardState.State_InDom:
                    return "[墓]";
                case CardState.State_InHandCard:
                    return "[手]";
                case CardState.State_InCardGroup:
                    return "[卡组]";
                case CardState.State_Null:
                    return "";
                case CardState.State_BackSet:
                    return "[伏]";
                default:
                    return "";
            }
        }
        public enum CardState
        {
            State_Att, State_Def, State_InDom, State_InHandCard, State_InCardGroup,State_Null,State_BackSet
        }

        public virtual void Die()
        {

        }

        



        //卡包含的全部触发:未完待续
        /// <summary>
        /// 加入手牌时
        /// </summary>
        public virtual void WhenAddToHandCard()
        {

        }
        /// <summary>
        /// 来到场上时
        /// </summary>
        public virtual void WhenAddToPlace()
        {

        }
        /// <summary>
        /// 发动效果时
        /// </summary>
        public virtual void WhenEffectOn()
        {

        }
        /// <summary>
        /// 效果被抹除打断时
        /// </summary>
        public virtual void WhenEffectBlock(IIsACatch catcher)
        {
            
        }
        /// <summary>
        /// 从场上离开时
        /// </summary>
        public virtual void WhenLeavePlace()
        {

        }
        /// <summary>
        /// 送入墓地时
        /// </summary>
        public virtual void WhenAddToGrave()
        {

        }
        /// <summary>
        /// 送入除外区时
        /// </summary>
        public virtual void WhenAddToException()
        {

        }

        /*public string Stateof()
        {
            if(this.State==CardState.State_Att)
            {
                return"【攻】";
            }
            else if(this.State==CardState.State_Def)
            {
                return "【守】";
            }
            else
            {
                return "";
            }
        }*/
    }
}
