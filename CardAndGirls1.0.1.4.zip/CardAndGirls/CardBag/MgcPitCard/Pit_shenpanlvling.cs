﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls.CardBag.MgcPitCard
{
    class Pit_shenpanlvling:Pit_Card,IIsACatch,IHaveEffect
    {
        public bool effectOn = false;
        public bool ToBlock { get; set; }
        public Card CardToEffect { get; set; }

        public MgcPit_Card MPCtoEffect { get; set; }

        public Pit_shenpanlvling()
        {
            this.ToBlock = false;
            base.Name = "审判律令";
            base.cardImage = Image.FromFile(".\\pic\\Pit_pic\\pit_shenpanlvling.png");
            base.Description = "①：对方的魔法·陷阱卡效果发动时才能发动，那个效果无效并且破坏。" +
                "\r\n\r\n“ ————吾在此守护，吾在此审判” ";
        }

        public override void WhenAddToPlace()
        {
            //优先触发Trigger_WhenAddToPlace
            
            if (WhenEffectOn_BeBlocked)
            {
                
            }
            else
            {
                Player.MainPlaceInfo.Catch_WhenEffectOn.Add(Catch);
                Player.MainPlaceInfo.MainFightPlace.textBox3.Text = this.Name + "启动Catch" + MainPlaceInfo.TriggerType.Trigger_WhenEffectOn;
            }
        }
        public override void WhenEffectOn()
        {
            //效果启动的时候优先发出触发Trigger_WhenEffectOn                     
            Player.MainPlaceInfo.Block_WhenEffectOn(this);
            if (WhenEffectOn_BeBlocked)
            {
                WhenEffectBlock(Catcher);
                Player.MainPlaceInfo.MainFightPlace.textBox3.Text = "【" + this.Player.Name + "   " + this.Name + "】效果被【" + Catcher.Player.Name + "    " + Catcher.Name + "】无效化";
            }
            else
            {
                Effect();
            }
        }

        public override void Effect()
        {
                
            CardToEffect.WhenEffectBlock(this);
            CardToEffect.Die();
            this.Die();
        }

        public override void WhenEffectBlock(IIsACatch catcher)
        {
            this.Catcher = catcher;
            this.WhenEffectOn_BeBlocked = true;

            CardToEffect.WhenEffectOn_BeBlocked = false;

        }


        public bool Catch(Card cardToBlock)
        {
            ToBlock = false;
            this.CardToEffect = cardToBlock;
            if (cardToBlock is MgcPit_Card && cardToBlock.Player != this.Player)
            {
                MgcPit_Card temp = (MgcPit_Card)cardToBlock;
                BlockDialog blockDialog = new BlockDialog(cardToBlock, this, MainPlaceInfo.TriggerType.Trigger_WhenEffectOn);
                blockDialog.ShowDialog();
                 if (ToBlock)
                 {
                    this.Player.MainPlaceInfo.Catch_WhenEffectOn.Remove(this.Catch);
                    WhenEffectOn();                   
                 }
                else
                {
                    this.Player.MainPlaceInfo.Catch_WhenEffectOn.Remove(this.Catch);
                }
            }
                
            return ToBlock;

        }

        public override void Die()
        {
            base.Die();
            this.Player.MainPlaceInfo.Catch_WhenEffectOn.Remove(this.Catch);
        }



    }
}
