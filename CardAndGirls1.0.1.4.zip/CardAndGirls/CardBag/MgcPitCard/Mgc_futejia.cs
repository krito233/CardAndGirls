﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CardAndGirls.CardBag.MgcPitCard
{
    
    public class Mgc_futejia : Mgc_Card,IHaveEffect
    {
        public bool effectOn = false;

        
        public int oldHp=4000;
        public int deltaHp=0;
        public Mgc_futejia()
        {
            base.Name = "伏特加";
            base.cardImage = Image.FromFile(".\\pic\\Magic_pic\\magic_futejia.png");
            base.Description = "①：本回合接下来自己受到的伤害为0。\r\n\r\n“ ————吨吨吨……嗝” ";
        }

        public override void Effect()
        {
            Checkfutejia check = new Checkfutejia(this, this.Player.MainPlaceInfo.Time);
            Player.TakeNoDemage();
            this.Die();
        }

        public override void WhenAddToHandCard()
        {
            
            //check.Show();//信息测试

            //Control.CheckForIllegalCrossThreadCalls = false;
           // monitor = new Thread(ForThead);
            //monitor.Start();
        }

        public override void WhenEffectBlock(IIsACatch catcher)
        {
            this.Catcher = catcher;
            WhenEffectOn_BeBlocked = true;
            Player.MainPlaceInfo.MainFightPlace.textBox3.Text = "【" + this.Player.Name + "   " + this.Name + "】效果被【" 
                + Catcher.Player.Name + "    " + Catcher.Name + "】无效化";
        }

        public override void WhenEffectOn()
        {
            //效果启动的时候优先发出触发Trigger_WhenEffectOn
            this.Player.MainPlaceInfo.Block_WhenEffectOn(this);//逐个询问是否对此次发动做出回应
            if (WhenEffectOn_BeBlocked)
            {
                WhenEffectBlock(Catcher);
                WhenEffectOn_BeBlocked = false;
            }
            else
            {
                Player.MainPlaceInfo.MainFightPlace.textBox3.Text = "【[普通魔法]伏特加】发动！本回合接下来受到伤害全部免除";
                Effect();    
            }
        }


        
        /* private void ForThead()
         {
             int oldHp = this.Player.Hp; //加入手牌时记录血量
             int time = this.Player.MainPlaceInfo.Time;//记录回合数
             while (true)
             {
                 if (time != this.Player.MainPlaceInfo.Time && Player.MainPlaceInfo.process == MainPlaceInfo.Process.GetCard
                     && this.Player.MainPlaceInfo.ActivePlayer == this.Player)
                 //如果走到下一个回合了，并且是我方的抽牌阶段
                 {
                     oldHp = Player.Hp;//把血量重置
                     time = this.Player.MainPlaceInfo.Time;//把回合数重置
                     break;
                 }
                 if (time == this.Player.MainPlaceInfo.Time && effectOn)//如果还是此回合，并且效果启动了，把血量一直保持oldHp;
                 {
                     if (Player.Hp < oldHp)//受到了伤害
                     {
                         Player.Hp = oldHp;
                         Player.MainPlaceInfo.MainFightPlace.textBox3.Text = "伏特加效果，本回合伤害免除";
                         break;
                     }
                 }
                 if (time != this.Player.MainPlaceInfo.Time && effectOn)
                 {
                     Player.MainPlaceInfo.MainFightPlace.textBox3.Text = "伏特加效果结束";
                     return;
                 }
                 if(time==this.Player.MainPlaceInfo.Time&&!effectOn)
                 {

                 }
             }
         }*/

    }
}
