﻿using CardAndGirls.CardBag.MgcPitCard;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CardAndGirls
{
    public partial class Checkfutejia : Form
    {
        Mgc_futejia futejia;
        
        int time;
        public Checkfutejia(Mgc_futejia futejia,int time)
        {
            this.time = time;
            this.futejia = futejia;
            InitializeComponent();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            {
                /* this.textBox1.Text = "Hp:" + futejia.Player.Hp + "\r\n" + "回合：" + time + "\r\n" + futejia.oldHp;

                 if (time == futejia.Player.MainPlaceInfo.Time && futejia.effectOn)//如果还是此回合，并且效果启动了，把血量一直保持oldHp;
                 {
                     if (futejia.Player.Hp < futejia.oldHp)//受到了伤害
                     {
                         futejia.deltaHp = futejia.oldHp - futejia.Player.Hp;
                         futejia.Player.Hp = futejia.oldHp;
                         futejia.Player.MainPlaceInfo.MainFightPlace.textBox3.Text = "伏特加效果，本回合伤害免除";

                     }
                 }
                 if (time != futejia.Player.MainPlaceInfo.Time && futejia.effectOn)
                 {

                     futejia.Player.MainPlaceInfo.MainFightPlace.textBox3.Text = "伏特加效果结束";
                     this.Close();
                     this.Dispose();
                 }
                 if (time != futejia.Player.MainPlaceInfo.Time && futejia.Player.MainPlaceInfo.process == MainPlaceInfo.Process.GetCard
         && futejia.Player.MainPlaceInfo.ActivePlayer == futejia.Player)
                 //如果走到下一个回合了，并且是我方的抽牌阶段
                 {
                     futejia.oldHp = futejia.Player.Hp;//把记录血量重置
                     time = futejia.Player.MainPlaceInfo.Time;//把回合数重置

                 }*/
            }//弃用
            if (time != futejia.Player.MainPlaceInfo.Time)
            {
                futejia.Player.StartTakeDemage();
            }
            
        }

        private void Checkfutejia_Load(object sender, EventArgs e)
        {
            /*this.Text = futejia.Player.Name;
            futejia.oldHp = futejia.Player.Hp; //加入手牌时记录血量
            time = futejia.Player.MainPlaceInfo.Time;//记录回合数*/
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
