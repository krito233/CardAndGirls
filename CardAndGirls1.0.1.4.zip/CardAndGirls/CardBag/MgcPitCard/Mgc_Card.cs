﻿using CardAndGirls.CardBag;
using CardAndGirls.CardBag.MgcPitCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls
{
    public class Mgc_Card:MgcPit_Card
    {
        public Mgc_Card()
        {
            base.Type = CardType.Mgc_Card;           
        }


    }
}
