﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls.CardBag.MgcPitCard
{
    public class Pit_Card:MgcPit_Card
    {
        public Pit_Card()
        {
            
            base.Type = CardType.Pit_Card;
        }
    }
}
