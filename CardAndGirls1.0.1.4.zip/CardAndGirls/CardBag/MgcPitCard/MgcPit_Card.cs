﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls.CardBag.MgcPitCard
{
    public class MgcPit_Card:Card,IHaveEffect
    {
        public Image backSetImage;
        public bool firstBackSet = false;

        public IIsACatch Catcher { get; set; }

        public MgcPit_Card()
        {
            this.WhenEffectOn_BeBlocked = false;
            base.State = CardState.State_Null;
            backSetImage = Image.FromFile(".\\pic\\magic_backset.jpg");
        }
        /// <summary>
        /// 效果发动（需要子类重写）
        /// </summary>
        public virtual void Effect()
        {

        }

        /// <summary>
        /// 送入墓地
        /// </summary>
        public override void Die()
        {
            this.State = CardState.State_InDom;
            if(Player.HandCardController.handCard.IndexOf(this)>=0)//说明是手牌发动
            {
                Player.Grave.graveCards.Add(Player.HandCardController.OneCardGiveOut(this));
            }
            else if(Player.MgcPit_Place.place.IndexOf(this)>=0)
            {
                int index = Player.MgcPit_Place.place.IndexOf(this);
                Player.MgcPit_Place.place[index] = Player.MgcPit_Place.mgcPit_null;
                Player.Grave.graveCards.Add(this);               
            }
            Player.CardGroupForm.Renew();

        }
        /// <summary>
        /// 覆盖结果
        /// </summary>
        /// <returns></returns>
        public virtual Mon_Card.CallResult BackSet()
        {
            return Mon_Card.CallResult.Success;
        }
        /// <summary>
        /// 刷新魔法陷阱卡区域
        /// </summary>
        public virtual void MgcPit_Renew()
        {
            this.firstBackSet = false;
        }
    }

}
