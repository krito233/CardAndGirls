﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CardAndGirls
{
    public partial class ParentForm : Form
    {
        public MainPlaceInfo MainPlaceInfo { get; set; }
        
        public ParentForm(MainPlaceInfo m)
        {
            this.MainPlaceInfo = m;
            InitializeComponent();
        }

        private void ParentForm_Load(object sender, EventArgs e)
        {
            MainPlaceInfo.MainFightPlace.Show();
        }

        public void RenewLocation()
        {
            Point point = MainPlaceInfo.MainFightPlace.Location;
            point.Y  -= 100;
            point.X -= 100;
            this.Location = point;
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
