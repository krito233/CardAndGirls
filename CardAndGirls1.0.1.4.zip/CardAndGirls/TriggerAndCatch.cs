﻿using CardAndGirls.CardBag;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CardAndGirls
{
    public partial class TriggerAndCatch : Form
    {

        List<Card> TriggerType_WhenAddToHandCard = new List<Card>(2);
        List<Card> TriggerType_WhenAddToPlace = new List<Card>(2);
        List<Card> TriggerType_WhenEffectOn = new List<Card>(2);
        List<Card> TriggerType_WhenEffectBlock= new List<Card>(2);
        List<Card> TriggerType_WhenLeavePlace = new List<Card>(2);
        List<Card> TriggerType_WhenAddToGrave = new List<Card>(2);
        List<Card> TriggerType_WhenAddToException= new List<Card>(2);

        List<IAbleToBlockProcess> TriggerType_CatchWhenAddToHandCard = new List<IAbleToBlockProcess>(5);
        List<IAbleToBlockProcess> TriggerType_CatchWhenAddToPlace = new List<IAbleToBlockProcess>(5);
        List<IAbleToBlockProcess> TriggerType_CatchWhenEffectOn = new List<IAbleToBlockProcess>(5);
        List<IAbleToBlockProcess> TriggerType_CatchWhenEffectBlock = new List<IAbleToBlockProcess>(5);
        List<IAbleToBlockProcess> TriggerType_CatchWhenLeavePlace = new List<IAbleToBlockProcess>(5);
        List<IAbleToBlockProcess> TriggerType_CatchWhenAddToGrave = new List<IAbleToBlockProcess>(5);
        List<IAbleToBlockProcess> TriggerType_CatchWhenAddToException = new List<IAbleToBlockProcess>(5);

        public MainPlaceInfo MainPlaceInfo { get; set; }

        BindingSource bs1 = new BindingSource();
        BindingSource bs2 = new BindingSource();
        BindingSource bs3 = new BindingSource();
        BindingSource bs4 = new BindingSource();

       
        public TriggerAndCatch()
        {
            InitializeComponent();
        }

        private void TriggerAndCatch_Load(object sender, EventArgs e)
        {
            /*//卡组
            bs1.DataSource = Player.CardGroup.cardList;
            listBox1.DataSource = bs1;
            listBox1.DisplayMember = "Name";
            //手牌
            bs2.DataSource = Player.HandCardController.handCard;
            listBox2.DataSource = bs2;
            listBox2.DisplayMember = "Name";
            //墓地
            bs3.DataSource = Player.Grave.graveCards;
            listBox3.DataSource = bs3;
            listBox3.DisplayMember = "Name";
            //除外区
            bs4.DataSource = Player.ExceptionPlace.ExceptionCards;
            listBox4.DataSource = bs4;
            listBox4.DisplayMember = "Name";*/
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if(TriggerType_CatchWhenAddToHandCard.Count!=0)
            {
                foreach (var item in TriggerType_CatchWhenAddToHandCard)
                {
                    item.BlockTheProcess();
                }
            }
        }
    }
}
