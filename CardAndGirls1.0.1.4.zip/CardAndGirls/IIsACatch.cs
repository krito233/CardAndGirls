﻿using CardAndGirls.CardBag;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardAndGirls
{
    /// <summary>
    /// 标记一个卡是捕获型的卡
    /// </summary>
    public interface IIsACatch
    {
        //一个捕获型卡需要提供他的玩家
        Player Player { get; set; }
        string Name { get; set; }
        Card CardToEffect { get; set; }
        //需要提供是否阻塞别人的判断
        bool ToBlock { get; set; }
    }
}
